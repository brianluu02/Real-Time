package spouts;

import lombok.extern.slf4j.Slf4j;
import org.apache.storm.spout.Scheme;
import org.apache.storm.tuple.Fields;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.util.ArrayList;
import java.util.List;


@Slf4j
// Implement the Scheme interface for deserializing messages in Apache Storm
public class RabbitMqScheme implements Scheme {

    // Override the deserialize method to convert a ByteBuffer into a list of objects
    @Override
    public List<Object> deserialize(ByteBuffer byteBuffer) {
        Charset charset = null;
        CharsetDecoder decoder = null;
        CharBuffer charBuffer = null;
        try {
            // Define the character set to be UTF-8
            charset = Charset.forName("UTF-8");
            // Create a decoder for the character set
            decoder = charset.newDecoder();
            // Decode the byte buffer into a character buffer
            charBuffer = decoder.decode(byteBuffer.asReadOnlyBuffer());

            // Create a list to store the deserialized message
            List list = new ArrayList<>(1);
            // Add the decoded message as a string to the list
            list.add(charBuffer.toString());
            // Return the list containing the deserialized message
            return list;
        } catch (Exception e) {
            // Log an error message if an exception occurs during deserialization
            log.error("RabbitMQ Scheme ERROR", e);
            // Return null to indicate an error
            return null;
        }
    }

    // Override the getOutputFields method to specify the output fields of the spout
    @Override
    public Fields getOutputFields() {
        // Return a Fields object with a single field named "message"
        return new Fields("message");
    }
}
