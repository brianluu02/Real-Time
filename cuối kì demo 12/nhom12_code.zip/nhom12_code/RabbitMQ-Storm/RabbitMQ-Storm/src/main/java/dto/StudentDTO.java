package dto;

import lombok.Data;

// Define the StudentDTO class with lombok-generated getters, setters, toString, equals, and hashCode methods
@Data
public class StudentDTO {
    // Declare private fields to represent the attributes of a student
    private int studentId;
    private String name;
    private String gender;
    private String orgName;
    private String orgNameChild;
    private String yearStudy;
    private double distance;
}

