import bolts.OutputBolt;
import bolts.WriterBolt;
import com.rabbitmq.client.ConnectionFactory;
import io.latent.storm.rabbitmq.Declarator;
import io.latent.storm.rabbitmq.RabbitMQSpout;
import io.latent.storm.rabbitmq.config.ConnectionConfig;
import io.latent.storm.rabbitmq.config.ConsumerConfig;
import io.latent.storm.rabbitmq.config.ConsumerConfigBuilder;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.apache.storm.generated.StormTopology;
import org.apache.storm.spout.Scheme;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.tuple.Fields;
import spouts.RabbitMqScheme;

import java.io.IOException;

// Define the main class for the Storm topology
@Slf4j
public class TopologyMain {

    // Define the RabbitMQ exchange, queue, and routing key
    private static String exchange = "exchange_app";
    private static String queue = "queue_app";
    private static String routingKey = "routing_key_app";
    public static final String EXCHANGE_TYPE = "topic";

    // Main method to set up and run the Storm topology
    @SneakyThrows
    public static void main(String[] args) {
        // Create a Storm topology builder
        TopologyBuilder builder = new TopologyBuilder();

        // Create a scheme for deserializing RabbitMQ messages
        Scheme scheme = new RabbitMqScheme();

        // Define a declarator to set up RabbitMQ exchange, queue, and binding
        Declarator declarator = (Declarator) channel -> {
            try {
                channel.exchangeDeclare(exchange, EXCHANGE_TYPE, true);
                channel.queueDeclare(queue, true, false, false, null);
                channel.queueBind(queue, exchange, routingKey);
                channel.basicQos(0, 250, false);
            } catch (IOException e) {
                // Log an error message if there's an issue with RabbitMQ setup
                log.error("ERROR: exchange:[{}],queue:[{}],routingKey:[{}],", exchange, queue, routingKey, e);
            }
            // Log a debug message after RabbitMQ setup
            log.debug("ERROR: exchange[{}],queue[{}],routingKey[{}]", exchange, queue, routingKey);
        };

        // Define connection configuration for RabbitMQ
        ConnectionConfig connectionConfig = new ConnectionConfig("localhost", 5672, "guest", "guest", ConnectionFactory.DEFAULT_VHOST, 10);

        // Define spout configuration for RabbitMQ
        ConsumerConfig spoutConfig = new ConsumerConfigBuilder().connection(connectionConfig)
                .queue("queue_app")
                .prefetch(200)
                .requeueOnFail()
                .build();

        // Create a RabbitMQ spout with the specified scheme and declarator
        RabbitMQSpout spout = new RabbitMQSpout(scheme, declarator);

        // Set up the spout in the topology builder
        builder.setSpout("PreOfflineSpout", spout, 1).addConfigurations(spoutConfig.asMap()).setMaxSpoutPending(200);

        // Set up the OutputBolt with parallelism of 4 and shuffle grouping from the spout
        builder.setBolt("OutputBolt", new OutputBolt(), 4).shuffleGrouping("PreOfflineSpout");

        // Set up the WriterBolt with parallelism of 8 and fields grouping from the OutputBolt based on "studentName"
        builder.setBolt("WriterBolt", new WriterBolt(), 8).fieldsGrouping("OutputBolt", new Fields("studentName"));

        // Set up Storm configuration
        Config conf = new Config();
        conf.setDebug(false);
        conf.setNumWorkers(5);
        conf.put(Config.TOPOLOGY_MAX_SPOUT_PENDING, 1);

        // Create the Storm topology
        StormTopology topology = builder.createTopology();

        // Set up a local cluster and submit the topology for execution
        LocalCluster cluster = new LocalCluster();
        cluster.submitTopology("HelloStorm", conf, topology);
    }
}
