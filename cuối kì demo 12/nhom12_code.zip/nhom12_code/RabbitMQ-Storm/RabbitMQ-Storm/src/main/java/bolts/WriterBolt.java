package bolts;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.BasicOutputCollector;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseBasicBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Slf4j
// Define the WriterBolt class that extends BaseBasicBolt
public class WriterBolt extends BaseBasicBolt {

	// Define constants for database connection details
	private static final String DB_USERNAME = "root";
	private static final String DB_PASSWORD = "B4hBEbgfdA1cDFda11C2b5BhC3gg6D1F";
	private static final String DB_HOSTNAME = "viaduct.proxy.rlwy.net";
	private static final String DB_PORT = "38479";
	private static final String DB_DATABASE = "strava";
	private static final String DB_TABLE = "user";

	// Track the batch number and total distance for each student
	private int batchNumber = 0;
	private Map<Integer, Double> totalDistanceMap = new HashMap<>();

	// Override the execute method to process incoming tuples
	@Override
	public void execute(Tuple tuple, BasicOutputCollector collector) {
		try {
			// Extract the message from the tuple
			String msg = tuple.getString(0);
			// Parse the JSON message into a JSONObject
			JSONObject jsonObject = JSON.parseObject(msg);
			// Extract relevant information from the JSON message
			int studentId = jsonObject.getIntValue("student_id");
			String name = jsonObject.getString("name");
			double distance = jsonObject.getDoubleValue("distance");
			// Calculate total distance for the student
			double totalDistance = distance;
			if (totalDistanceMap.containsKey(studentId)) {
				// If already exists, add the distance to the existing total distance
				totalDistance += totalDistanceMap.get(studentId);
			}
			// Update the total distance map
			totalDistanceMap.put(studentId, totalDistance);
			log.info("---------------------------------------");

			log.info("Student Id: " + studentId);
			log.info("Name: " + name);
			log.info("Distance: " + distance);
			log.info("Total Distance: " + totalDistance);

			log.info("---------------" + LocalDateTime.now() + "-----------------------");

			// Save data to MySQL every 20 seconds (adjust as needed)
			if (isThirtySecondsBatch()) {
				batchNumber += 1;
				saveDataToMySQL(batchNumber);
			}

			// Emit values to the next bolt
			collector.emit(new Values(msg, name));
		} catch (Exception e) {
			// Log any exceptions that occur during tuple processing
			e.printStackTrace();
		}
	}
	// Track the start time of the current batch
	private long batchStartTime = -1;
	// Check if 30 seconds have passed since the start of the batch
	private boolean isThirtySecondsBatch() {
		long currentTime = System.currentTimeMillis();

		// If it's the start of the batch, initialize the batch start time
		if (batchStartTime == -1) {
			batchStartTime = currentTime;
			return false; // Don't process the batch yet
		}

		// Check if 30 seconds have passed since the start of the batch
		if (currentTime - batchStartTime >= 20000) { // 20,000 milliseconds = 20 seconds
			// Reset batch start time for the next batch
			batchStartTime = currentTime;
			return true; // Process the batch
		}

		return false; // Don't process the batch yet
	}
	// Save the data to MySQL
	private void saveDataToMySQL(Integer batchNumber) {
		try (Connection connection = DriverManager.getConnection("jdbc:mysql://"+DB_HOSTNAME+":"+DB_PORT+"/"+DB_DATABASE+"", DB_USERNAME, DB_PASSWORD)) {
			// Adjust the SQL statement based on your database schema
			String sql = "INSERT INTO "+DB_TABLE+" (batch, mssv, total_distance) VALUES (?, ?, ?)";

			try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
				// Iterate through the total distance map and add entries to the batch
				for (Map.Entry<Integer, Double> entry : totalDistanceMap.entrySet()) {
					preparedStatement.setInt(1, batchNumber);
					preparedStatement.setInt(2, entry.getKey());
					preparedStatement.setDouble(3, entry.getValue());
					preparedStatement.addBatch();
				}
				// Execute the batch update
				preparedStatement.executeBatch();
			}
		} catch (SQLException e) {
			// Log an error message if there's an issue with saving data to MySQL
			log.error("Error saving data to MySQL", e);
		}
	}
	// Override the prepare method to initialize resources before processing starts
	@Override
	public void prepare(Map stormConf, TopologyContext context) {
		try {
			// Load the MySQL JDBC driver
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// Log an error message if the MySQL JDBC driver is not found
			log.error("MySQL JDBC driver not found", e);
		}
	}

	// Override the declareOutputFields method to specify the output fields of the bolt
	@Override
	public void declareOutputFields(OutputFieldsDeclarer arg0) {
		// Declare output fields as "result"
		arg0.declare(new Fields("result"));
	}
}