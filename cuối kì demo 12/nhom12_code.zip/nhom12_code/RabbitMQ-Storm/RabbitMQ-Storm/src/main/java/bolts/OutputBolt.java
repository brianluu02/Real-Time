package bolts;

import com.alibaba.fastjson.JSON;
import dto.StudentDTO;
import org.apache.storm.shade.org.apache.commons.lang.StringUtils;
import org.apache.storm.topology.BasicOutputCollector;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseBasicBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Define the OutputBolt class that extends BaseBasicBolt
public class OutputBolt extends BaseBasicBolt {
	private static final Logger log = LoggerFactory.getLogger(OutputBolt.class);

	// Override the execute method to process incoming tuples
	@Override
	public void execute(Tuple tuple, BasicOutputCollector collector) {
		try {
			// Extract the message from the tuple
			String msg = tuple.getString(0);

			// Log the start of tuple processing
			log.info("************************************");
			log.info("OutputBolt execute tuple {} ", msg);

			// Parse the JSON message into a StudentDTO object
			StudentDTO studentDTO = JSON.parseObject(msg, StudentDTO.class);

			// Check if the student name is empty
			if(StringUtils.isEmpty(studentDTO.getName())) {
				log.info("Student name is empty!!");
			}

			// Emit a new tuple with the original message and the student's name
			collector.emit(new Values(msg, studentDTO.getName()));
		} catch (Exception e) {
			// Log any exceptions that occur during tuple processing
			e.printStackTrace();
		}
	}

	// Override the declareOutputFields method to declare the output fields
	@Override
	public void declareOutputFields(OutputFieldsDeclarer declare) {
		// Declare output fields as "studentDTO" and "studentName"
		declare.declare(new Fields("studentDTO", "studentName"));
	}
}
