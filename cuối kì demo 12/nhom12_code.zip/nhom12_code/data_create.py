# Import necessary libraries
from datetime import datetime
import json
import random
import pika
import pandas as pd
import time

# Establish connection to RabbitMQ server
connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()

# Declare queue, exchange, and binding information
queue_name = 'queue_app'
exchange_name = 'exchange_app'
routing_key = 'routing_key_app'

channel.queue_declare(queue=queue_name, durable=True)
channel.exchange_declare(exchange=exchange_name, exchange_type='topic', durable=True)
channel.queue_bind(exchange=exchange_name, queue=queue_name, routing_key=routing_key)

# Main block of the script
if __name__ == "__main__":
    print("RabbitMQ Producer Application Started ... ")

    # Read data from CSV file using pandas
    data = pd.read_csv("./data/student.csv")
                            
    # Extract the students from the data
    student_list = data['student'].tolist()
    
    # Generate and send 100 messages
    for i in range(100):
        i = i + 1
        message = {}
        print("Preparing message: " + str(i))
        
        # Get the current datetime
        event_datetime = datetime.now()

        # Extract information from a randomly chosen student
        student = random.choice(student_list)
        student_id, name, gender, org_name, org_name_child, year_study = student.split(",")
        
        # Populate the message dictionary
        message["student_id"] = student_id
        message["name"] = name
        message["gender"] = gender
        message["org_name"] = org_name
        message["org_name_child"] = org_name_child
        message["year_study"] = year_study
        message["distance"] = round(random.uniform(1.5, 11.5), 1)
        message["start_date_local"] = event_datetime.strftime("%Y-%m-%d %H:%M:%S")
        
        # Convert the message dictionary to JSON format
        data_json = json.dumps(message)
        
        # Publish the message to RabbitMQ
        channel.basic_publish(
            exchange=exchange_name,
            routing_key=routing_key,
            body=data_json,
            properties=pika.BasicProperties(
                delivery_mode=2,  # Make the message persistent
            )
        )
        
        print("Message: ", message)
        
        # Pause for 2 seconds before sending the next message
        time.sleep(2)
    
    # Close the RabbitMQ connection
    connection.close()
    print("RabbitMQ Producer Application Completed. ")
