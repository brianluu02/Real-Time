echo "-->> Start, Script for Storm.";

# remove old files
rm -r StormApp*
rm -r data*
rm -r result*

# download storm application jar
wget http://$1/download/StormApp.jar

# run script in loop
for i in $(seq 1 5)
do
  # wait loop here for 30 second
	sleep 30
  echo "-->> Start, sales analysis using Storm - $i";

  # download data file
  wget http://$1/download/data_$i.csv

  # run storm application jar files and pass input for file number
  java -jar StormApp.jar $i

  # upload result file
  curl -X POST http://$1/upload -H 'content-type: multipart/form-data' -F file=@result_$i.csv
	echo "-->> Result file is uploaded - $i";


done
echo "-->> End, Script for Storm.";
