from pyspark import SparkContext
from pyspark.streaming import StreamingContext

# Tạo SparkContext
sc = SparkContext("local[2]", "SlidingWindowDemo")

# Tạo StreamingContext với batch interval là 1 giây
ssc = StreamingContext(sc, 1)

# Tạo một DStream từ nguồn dữ liệu (ví dụ: socket)
lines = ssc.socketTextStream("localhost", 9999)

# Xử lý dữ liệu trong sliding windows
windowed_lines = lines.window(windowDuration=10, slideDuration=5)

# Đếm số từ trong mỗi cửa sổ
word_counts = windowed_lines.flatMap(lambda line: line.split(" ")) \
    .map(lambda word: (word, 1)) \
    .reduceByKey(lambda x, y: x + y)

# In kết quả
word_counts.pprint()

# Bắt đầu quá trình streaming
ssc.start()

# Chờ quá trình streaming kết thúc
ssc.awaitTermination()

